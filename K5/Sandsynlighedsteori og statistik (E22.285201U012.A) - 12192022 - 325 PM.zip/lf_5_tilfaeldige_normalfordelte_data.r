

## Opgave om genererede normalfordelte tal

n = 1000
# n = 10

x = rnorm(n)

qqnorm(x)